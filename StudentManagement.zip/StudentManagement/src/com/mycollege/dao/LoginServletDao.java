package com.mycollege.dao;

import java.util.List;

import com.mycollege.model.Student;
import com.mycollege.model.User;

public interface LoginServletDao {
		public void loginValidate(String userName,String Password);
	 	public int addStudent( Student student );
	    public int deleteStudent( int studentId );
	    public void updateStudent( Student student );
	    public List<Student> getAllStudents();
	    public Student getStudentById( int studentId );
		public int createAccount(User user);
		public int editStudent(Student student);
		
}
