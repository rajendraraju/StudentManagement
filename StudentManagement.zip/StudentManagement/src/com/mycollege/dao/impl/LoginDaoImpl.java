package com.mycollege.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mycollege.dao.LoginServletDao;
import com.mycollege.model.Student;
import com.mycollege.model.User;
import com.mycollege.utill.dbConnect;

public class LoginDaoImpl implements LoginServletDao{
	
	 private Connection conn;
	 
	    public  void LoginDaoImpl() {
	        conn = dbConnect.getConnection();
	    }

	public int addStudent(Student student) {
		int insertStatus = 0;
		try {
            String query = "insert into student(firstName,lastName,course,phoneNumber,email,dateOfBirth,year,address) values (?,?,?,?,?,?,?,?)";
            PreparedStatement preparedStatement = conn.prepareStatement( query );
            preparedStatement.setString( 1, student.getFirstName() );
            preparedStatement.setString( 2, student.getLastName() );
            preparedStatement.setString( 3, student.getCourse() );
            preparedStatement.setString(4, student.getPhoneNumber());
            preparedStatement.setString(5,student.getEmail());
            preparedStatement.setString(6,student.getDateOfBirth());
            preparedStatement.setInt(7,student.getYear());
            preparedStatement.setString(8,student.getAddress());
            insertStatus = preparedStatement.executeUpdate();
            
            preparedStatement.close();
            
            if(insertStatus > 0){
            	String rolesQuery = "insert into roles (role, name) values (?,?)";
                PreparedStatement rolespreparedStatement = conn.prepareStatement(rolesQuery);
                rolespreparedStatement.setString( 1,"student");
                rolespreparedStatement.setString( 2,student.getFirstName());
                insertStatus =  rolespreparedStatement.executeUpdate();
                rolespreparedStatement.close();
                
                if(insertStatus>0){
                	String usersquery = "insert into users (name, password) values (?,?)";
                    PreparedStatement userpreparedStatement = conn.prepareStatement(usersquery);
                    preparedStatement.setString( 1,student.getFirstName());
                    preparedStatement.setString( 2,"password");
                    insertStatus =  preparedStatement.executeUpdate();
                    preparedStatement.close();
                }
                
            }
			
        } catch (SQLException e) {
            e.printStackTrace();
        }
		return insertStatus;
	}

	public int deleteStudent(int studentId) {
		int deleteStatus = 0;
		try {
            String query = "delete from student where id=?";
            PreparedStatement preparedStatement = conn.prepareStatement(query);
            preparedStatement.setInt(1, studentId);
            deleteStatus = preparedStatement.executeUpdate();
            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
		
		return deleteStatus;
		
	}

	public void updateStudent(Student student) {
		
	}

	public List<Student> getAllStudents() {
		List<Student> students = new ArrayList<Student>();
		  conn = dbConnect.getConnection();
        try {
            Statement statement = conn.createStatement();
            ResultSet resultSet = statement.executeQuery( "select * from student" );
            while( resultSet.next() ) {
                Student student = new Student();
                student.setId( resultSet.getInt("id"));
                student.setFirstName( resultSet.getString( "firstName" ) );
                student.setLastName( resultSet.getString( "lastName" ) );
                student.setCourse( resultSet.getString( "course" ) );
                student.setYear( resultSet.getInt( "year" ) );
                student.setAddress(resultSet.getString("address"));
                student.setDateOfBirth(resultSet.getString("dateOfBirth"));
                student.setPhoneNumber(resultSet.getString("phoneNumber"));
                student.setEmail(resultSet.getString("email"));
                students.add(student);
            }
            resultSet.close();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
	}

	public Student getStudentById(int studentId) {
		Student student = new Student();
		conn = dbConnect.getConnection();
        try {
            String query = "select * from student where id=?";
            PreparedStatement preparedStatement = conn.prepareStatement( query );
            preparedStatement.setInt(1, studentId);
            ResultSet resultSet = preparedStatement.executeQuery();
            while( resultSet.next() ) {
            	student.setId( resultSet.getInt("id") );
                student.setFirstName( resultSet.getString( "firstName" ) );
                student.setLastName( resultSet.getString( "lastName" ) );
                student.setCourse( resultSet.getString( "course" ) );
                student.setYear( resultSet.getInt( "year" ) );
                student.setAddress(resultSet.getString("address"));
                student.setDateOfBirth(resultSet.getString("dateOfBirth"));
                student.setPhoneNumber(resultSet.getString("phoneNumber"));
                student.setEmail(resultSet.getString("email"));
            }
            resultSet.close();
            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return student;
	}
	
	
	public Student getStudentByName(String studentName) {
		Student student = new Student();
		conn = dbConnect.getConnection();
        try {
            String query = "select * from student where firstName=?";
            PreparedStatement preparedStatement = conn.prepareStatement( query );
            preparedStatement.setString(1, studentName);
            ResultSet resultSet = preparedStatement.executeQuery();
            while( resultSet.next() ) {
            	student.setId( resultSet.getInt("id") );
                student.setFirstName( resultSet.getString( "firstName" ) );
                student.setLastName( resultSet.getString( "lastName" ) );
                student.setCourse( resultSet.getString( "course" ) );
                student.setYear( resultSet.getInt( "year" ) );
                student.setAddress(resultSet.getString("address"));
                student.setDateOfBirth(resultSet.getString("dateOfBirth"));
                student.setPhoneNumber(resultSet.getString("phoneNumber"));
                student.setEmail(resultSet.getString("email"));
            }
            resultSet.close();
            preparedStatement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return student;
	}

	public String loginValidate(String userName, String Password) {
		
		int  status =0;
		String role = null;
		 conn = dbConnect.getConnection();
		try{
			String query = "select name from users where name=? and password=?";
            PreparedStatement preparedStatement = conn.prepareStatement(query);
            preparedStatement.setString( 1,userName);
            preparedStatement.setString( 2,Password);
            ResultSet result =  preparedStatement.executeQuery();
          
            
            if(result!=null){
            	String rolesQuery = "select * from roles where name=?";
            	System.out.println(rolesQuery);
            	 PreparedStatement rolespreparedStatement = conn.prepareStatement(rolesQuery);
            	 rolespreparedStatement.setString( 1,userName);
                 ResultSet resuleset =  rolespreparedStatement.executeQuery();
                 while(resuleset.next()){
                	  role =  resuleset.getString(2);
                 }
                 rolespreparedStatement.close();
            }
            preparedStatement.close();
           
		}catch(Exception exce){
			exce.printStackTrace();
		}
		return role;
	}

	public int createAccount(User user) {
		int status = 0 ;
		 conn = dbConnect.getConnection();
		try{
			String query = "insert into users (name, email, password) values (?,?,?)";
            PreparedStatement preparedStatement = conn.prepareStatement(query);
            preparedStatement.setString( 1,user.getName());
            preparedStatement.setString( 2,user.getEmail());
            preparedStatement.setString( 3,user.getPassword());
           
           status =  preparedStatement.executeUpdate();
            preparedStatement.close();
            
            
		}catch(Exception exce){
			exce.printStackTrace();
		}
		return status;
	
	}

	public int editStudent(Student student) {
		int status = 0 ;
		 conn = dbConnect.getConnection();
		try{
			if(student != null){
				String query = "update student set firstName = ?,lastName =?,course =?,phoneNumber=? ,email=?,dateOfBirth=?,year=?,address=? where id=? ";
	            PreparedStatement preparedStatement = conn.prepareStatement(query);
	            preparedStatement.setString(1,student.getFirstName());
	            preparedStatement.setString( 2,student.getLastName());
	            preparedStatement.setString( 3,student.getCourse());
	            preparedStatement.setString( 4,student.getPhoneNumber());
	            preparedStatement.setString( 5,student.getEmail());
	            preparedStatement.setString( 6,student.getDateOfBirth());
	            preparedStatement.setInt( 7,student.getYear());
	            preparedStatement.setString( 8,student.getAddress());
	            preparedStatement.setInt( 9,student.getId());
	           
	           status =  preparedStatement.executeUpdate();
	            preparedStatement.close();
			}
			
		}catch(Exception exe){
			exe.printStackTrace();
		}
		
		return status;
	}
	
	
	

}
