package com.mycollege.test;

import java.util.List;

import com.mycollege.dao.impl.LoginDaoImpl;
import com.mycollege.model.Student;

public class Testing {

	public static void main(String[] args) {
		
		
		LoginDaoImpl dao = new LoginDaoImpl();
		
		List<Student> stdlist = dao.getAllStudents();
		
		for(Student s:stdlist){
			System.out.println(s.getFirstName());
		}
		
	}

}
