package com.mycollege.controler;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mycollege.dao.LoginServletDao;
import com.mycollege.dao.impl.LoginDaoImpl;
import com.mycollege.model.Student;
import com.mycollege.model.User;

public class LoginServlet extends HttpServlet {
	
	private LoginServletDao dao;
    private static final long serialVersionUID = 1L;
    public static final String lIST_STUDENT = "WEB-INF/pages/listStudent.jsp";
    public static final String INSERT_OR_EDIT = "/student.jsp";
    
    public static final String LOGIN = "/login.jsp";
 
    public LoginServlet() {
        dao = new LoginDaoImpl();
    }
 
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String forward = "";
        String action = request.getParameter( "action" );
        PrintWriter out = response.getWriter();
        
        if( action.equalsIgnoreCase( "delete" ) ) {
            forward = lIST_STUDENT;
            int studentId = Integer.parseInt( request.getParameter("id") );
            int deleteStatus = dao.deleteStudent(studentId);
            System.out.println("deleteStatus::"+deleteStatus);
            request.setAttribute("students", dao.getAllStudents() );
        }
        else if( action.equalsIgnoreCase( "edit" ) ) {
        	forward = lIST_STUDENT;
        	
        	Student student = new Student();
        	student.setId(Integer.parseInt(request.getParameter("id")));
        	student.setFirstName(request.getParameter("firstName"));
        	student.setLastName(request.getParameter("lastName"));
        	student.setCourse(request.getParameter("course"));
        	student.setEmail(request.getParameter("email"));
        	student.setPhoneNumber(request.getParameter("phoneNumber"));
        	student.setYear(Integer.parseInt(request.getParameter("year")));
        	student.setDateOfBirth(request.getParameter("dateOfBirth"));
        	student.setAddress(request.getParameter("address"));
        	if(student.getId()>0){
        		int updateStatus = dao.editStudent(student);
        		if(updateStatus>0){
        			 request.setAttribute("students", dao.getAllStudents() );
                	
        		}
            	System.out.println("updateStatus****"+updateStatus);
        	}
        	
        	
        }
        else if( action.equalsIgnoreCase( "insert" ) ) {
        	
        	forward = lIST_STUDENT;
        	
        	Student student = new Student();
        	student.setFirstName(request.getParameter("firstName"));
        	student.setLastName(request.getParameter("lastName"));
        	student.setCourse(request.getParameter("course"));
        	student.setEmail(request.getParameter("email"));
        	student.setPhoneNumber(request.getParameter("phoneNumber"));
        	student.setYear(Integer.parseInt(request.getParameter("year")));
        	student.setDateOfBirth(request.getParameter("dateOfBirth"));
        	student.setAddress(request.getParameter("address"));
        	if(student.getId()>0){
        		int insertStatus = dao.addStudent(student);;
        		if(insertStatus>0){
        			 request.setAttribute("students", dao.getAllStudents() );
                	
        		}
            	System.out.println("insertStatus****"+insertStatus);
        	}
        	
        }else if( action.equalsIgnoreCase( "allStudents" ) ) {
        	
        	List<Student>studentsdList = dao.getAllStudents();
        	if(studentsdList != null){
        		System.out.println("studentsdList size***"+studentsdList.size());
        		request.setAttribute("students",studentsdList);
        	}
        	
            forward = lIST_STUDENT;
        }else if( action.equalsIgnoreCase( "createAccount" ) ) {
        	User user = new User();
        		String name = request.getParameter("name" );
        		String gmail = 	request.getParameter("email" );
        		String password = request.getParameter("password" );
        		 user.setName(name);
        		 user.setEmail(gmail);
        		 user.setPassword(password);
        		 
        		 if(user != null && name != null && gmail != null ){
        			 int status = dao.createAccount(user);
        			 System.out.println("account status:"+status);
        		 }
        		 
        }
        else {
           /* forward = lIST_STUDENT;
            request.setAttribute("students", dao.getAllStudents() );*/
        }
        RequestDispatcher view = request.getRequestDispatcher( forward );
        view.forward(request, response);
        
     
    }
 
   

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	response.setContentType("text/html");
		PrintWriter out= response.getWriter();
		
		 RequestDispatcher view = request.getRequestDispatcher( LOGIN );
	        view.forward(request, response);
	        
    }
    
    

    
    
}
	

